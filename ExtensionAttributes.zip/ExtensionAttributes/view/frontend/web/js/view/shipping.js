initialize: function (config) {
this.sample_attribute = ko.observable();
}

 
