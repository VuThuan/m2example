
# EXTENSION ATTRIBUTES IN MAGENTO2 Checkout




Ref:

https://www.dckap.com/blog/extension-attributes-in-magento2/
